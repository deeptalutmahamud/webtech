<!DOCTYPE html>
<html>
<head>

</head>
<body>
  <?php
  
    $nameErr=$emailErr=$usnameErr=$pass2Err=$pass3Err=$genderErr=$dateErr=$phoneErr=$addressErr="";
    $name=$email=$usname=$pass2=$pass3=$gender=$date=$message=$phone=$address="";
    if($_SERVER["REQUEST_METHOD"]=="POST")
  {
    if(empty($_POST["name"]))
    {
      $nameErr="Name is required";
    }
    else
    {

      $name=$_POST["name"];
      if(!preg_match("/^[a-zA-Z- ]*$/",$name))
      {
        $nameErr="Must start with a letter. Can contain a-z, A-Z, period, dash only";
        $name="";
        
      }
    }
    if(empty($_POST["email"]))
    {
      $emailErr="Email is required";
    }
    else
    {

      $email=$_POST["email"];
      if(!filter_var($email, FILTER_VALIDATE_EMAIL))
      {
        $emailErr="Invalid email format";
        $email="";
      }
    }
    if(empty($_POST["usname"]))
    {
      $usnameErr="Username is required";
    }
    else
    {
 
      $usname=$_POST["usname"];
      if(strlen($_POST["usname"])<2)
      {
        $usnameErr="User Name must contain at least two (2) characters";
        $usname="";
      }

    }
    if(empty($_POST["phone"]))
    {
      $phoneErr="Phone Number is required";
    }


      $phone=$_POST["phone"];
      
       if(!preg_match("/^[0-9]{11}+$/",$phone))
      {
        $phoneErr="Phone number contain at 11 number and no letter";
        $phone="";
        
      
    }
    if(empty($_POST["address"]))
    {
      $addressErr="Address is required";
    }
    else
    {

      $address=$_POST["address"];
      if(!preg_match("/^[a-zA-Z0-9, ]*$/",$address))
      {
        $addressErr="Not found";
        $address="";
        
      }
    }
    if(empty($_POST["gender"]))
    {
      $genderErr="Gender is required";
      $gender="";
    }
    else
    {
 
      $gender=$_POST["gender"];
    }

    

    
    if($name!="" and $email!= "" and $usname!="" and $gender!="" and  $pass3!="" and $phone!="" and $address!="" )
    {
      
      $current=file_get_contents('data.json');
      $array=json_decode($current,true);
      $new=array(
      'name' => $_POST["name"],
      'email' => $_POST["email"],
      'username' => $_POST["usname"],
      'phone' =>$_POST["phone"],
      'address' => $_POST["address"],
     
      );
      
    
  }
    else{
      $message="enter the information";

    }

  }   

    

  
  ?>

  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    <div style="height: 700px;">
      
    
    <fieldset >
        
    <legend><h2>General</h2>    </legend>

   
    <label for="name">First Name:</label>
   <input type="text" name="name" id="name"><br><span><?php echo $nameErr;?></span><br><hr>
   <label for="usname">Last Name:</label>
    <input type="text" name="usname" id="usname"><br><span><?php echo $usnameErr;?></span><br><hr>

    <style="width: 330px;height: 30px;">
      <legend>Gender</legend>
       <input type="radio" name="gender" id="g1" value="Male">
       <label for="g1">Male</label>
        <input type="radio" name="gender" id="g2" value="Female">
        <label for="g2">Female</label>
         <input type="radio" name="gender" id="g3" value="Other">
         <label for="g3">Other</label><br>
         <br><span><?php echo $genderErr;?></span>
    <br><hr>


</fieldset >
  <br>
  <br>

  <fieldset >
        
        <legend><h2>Contact</h2>    </legend>

     <label for="email">Email:</label>
    <input type="text" name="email" id="email"><br><span><?php echo $emailErr;?></span><br><hr>
    
    <label for="phone">Phone Number:</label>
    <input type="text" name="phone" id="phone"><br><span><?php echo $phoneErr;?></span><br><hr>
     
    </fieldset >
    <br>
    <br>
   
    <fieldset >
        
        <legend><h2>Address</h2>    </legend>

    <label for="address">Street/House/Road</label>
    <input type="text" name="address" id="address"><br><span><?php echo $addressErr;?></span><br><hr>

    <br>
    <label for="country">Country</label>
			<select name="country" id="country">
				<option value="bd">Bangladesh</option>
				<option value="usa">United States of America</option>
        <option value="india">India</option>
			</select>
</fieldset >

    <input type="submit" name="submit" value="submit">
      
      <input type="reset" name="reset" value="reset"><br><span><?php echo $message?></span>
      
     
</div>

  
  </form>
</body>
</html>