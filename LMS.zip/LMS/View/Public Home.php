<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href="../CSS/style.css">
<title></title>
    <style>

    </style>
</head>
<?php require("head.php"); ?>

<h1 class="my-content">Welcome to Online Library</h1>

<?php require("foot.php"); ?>
