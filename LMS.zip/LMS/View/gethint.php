<?php
// Array with names
$a[] = "A passage to india";
$a[] = "Bomkesh bokshi";
$a[] = "Mrittu Ban";
$a[] = "Himu";
$a[] = "Kobita";
$a[] = "Frankensten";
$a[] = "Goyenda";
$a[] = "Hege";
$a[] = "Intovert";
$a[] ="Jibon Theke";
$a[] = "Kotha";
$a[] = "Lion";
$a[] = "Naina";
$a[] = "Ophelia";
$a[] = "Petunia";
$a[] = "Akla";
$a[] = "Physic 2";
$a[] = "zzz";
$a[] = "xx";
$a[] = "Elen";
$a[] = "Evita";
$a[] = "Sunniva";
$a[] = "Tove";
$a[] = "Unni";
$a[] = "Violet";
$a[] = "Liza";
$a[] = "Elizabeth";
$a[] = "Ellen";
$a[] = "Wenche";
$a[] = "Vicky";

// get the q parameter from URL
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from ""
if ($q !== "") {
  $q = strtolower($q);
  $len=strlen($q);
  foreach($a as $name) {
    if (stristr($q, substr($name, 0, $len))) {
      if ($hint === "") {
        $hint = $name;
      } else {
        $hint .= ", $name";
      }
    }
  }
}

// Output "no suggestion" if no hint was found or output correct values
echo $hint === "" ? "no suggestion" : $hint;
?>